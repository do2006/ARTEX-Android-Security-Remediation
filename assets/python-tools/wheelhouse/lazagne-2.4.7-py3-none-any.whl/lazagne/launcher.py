from pathlib import Path
from runpy import run_path

def main():
    run_path(str(Path(__file__).with_name("_cli.py")), run_name="__main__")
